export const APPLE = '苹果';
export const BANANA = '香蕉';

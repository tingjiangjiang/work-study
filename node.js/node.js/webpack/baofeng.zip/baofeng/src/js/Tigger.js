// import { Animal, myName } from './Animal';
import { myName } from './Animal';
import Animal from './Animal'; //默认导入

// import { APPLE, BANANA } from './Interface';
import * as Fruit from './Interface';

// let animal = require('./Animal')
class Tigger extends Animal {
	constructor() {
		super();
		this.title = '老虎';
	}
	say() {
		console.log('大老虎');
	}
}
console.log(myName);
console.log(Fruit.APPLE);

export { Tigger };
